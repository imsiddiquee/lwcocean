import { api, LightningElement } from "lwc";

export default class PublicConfigureProperty extends LightningElement {
    @api label = "WIPDeveloper.com  !!!";
}
